# Cruella Store.ID — siap GitHub Pages

## File utama
- `index.html` — website + SEO meta + structured data
- `robots.txt` — aturan crawler
- `sitemap.xml` — sitemap Google
- `.nojekyll` — memastikan file statis disajikan apa adanya

## Publish
1. Upload seluruh isi ZIP ke root repository `Cruella-id` pada branch `main`.
2. GitHub → repository → **Settings → Pages**.
3. Pada **Build and deployment**, pilih **Deploy from a branch**, branch `main`, folder `/ (root)`, lalu Save.
4. Setelah publish, buka `https://jalantikusahuy-cpu.github.io/Cruella-id/`. GitHub mencatat perubahan Pages dapat membutuhkan beberapa menit untuk tampil.
5. Setelah website aktif, verifikasi di Google Search Console dan submit `https://jalantikusahuy-cpu.github.io/Cruella-id/sitemap.xml`.

## Jika nanti memakai domain sendiri
Ganti URL `https://jalantikusahuy-cpu.github.io/Cruella-id/` di `index.html`, `robots.txt`, dan `sitemap.xml` dengan domain resmi. Lalu atur Custom domain di Settings → Pages dan DNS provider.

## Catatan
Website tidak menjamin posisi/ranking tertentu di Google. Pastikan harga, nomor WhatsApp, dan akun media sosial selalu benar sebelum dipublikasikan.
