CRUELLA STORE.ID — PANDUAN SETELAH UPLOAD

1. Upload index.html, robots.txt, dan sitemap.xml ke folder utama hosting.
2. Ganti GANTI-DENGAN-DOMAIN-KAMU.com di index.html, robots.txt, dan sitemap.xml dengan domain website asli.
3. Buka Google Search Console: https://search.google.com/search-console/
4. Tambahkan domain/URL-prefix website dan selesaikan verifikasi kepemilikan.
5. Di Search Console, buka Sitemaps lalu kirim: sitemap.xml
6. Gunakan URL Inspection untuk meminta pengindeksan halaman utama.

Catatan: pengindeksan Google tidak selalu instan dan tidak menjamin posisi tertentu di hasil pencarian.
